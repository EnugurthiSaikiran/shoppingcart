import React from 'react';
//import logo from './logo.svg';
import './App.css';
import Home from './Home';
import Signup from './Signup';
import Navbar from './Navbar';
import {Route} from 'react-router-dom';
function App(props) {
  return (
    <div className="App">
      <Navbar/>
     <div className="container my-4">
                <Route path="/" exact component={Home} />
                <Route path="/signup" exact component={Signup} />
                
            </div>
    </div>
  );
}

export default App;
