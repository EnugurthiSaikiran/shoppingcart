import React from 'react';
import './Home.css';
import {Link} from 'react-router-dom';
function Home(props) {
    
    return (
        <div >
            <div class='text-center'>
           <form name="myForm" method="post">
               Name:
               <table align="center">
              <input type="text" name="name" required/><br/>
              <div class="col-md-6">
                  Password:
              <input id="password-field" type="password" class="form-control" name="password" required/>
       
               </div>
        
           

           <div>
           <button name="signup">
               <Link type="button" className="" to="/Signup" >Signup</Link>
               </button>
               <span>
               <button type="submit" >Submit</button>
               
           </span>
           </div>
           </table>
          </form>
           </div>

        </div>
        
    );
}

export default Home;