import React from 'react';
import './Signup.css';
function Signup(props) {
    return (
        <div>
            <form>
            <div class="container">
            
                <table align="center">
               <tr><label for="uname"><b>Firstname:</b></label>&nbsp;&nbsp;&nbsp;
               <input type="text" placeholder="Enter Firstname" name="fname" required></input>
               <br/></tr>
               <tr><label for="lname"><b>Lastname:</b></label>&nbsp;&nbsp;&nbsp;
               <input type="text" placeholder="Enter Lastname" name="lname" required></input>
               </tr>
               <tr>
               <label for="email"><b>Email</b></label>&nbsp;&nbsp;&nbsp;
               <input type="text" placeholder="Enter Email" name="email" required/>
                </tr>
                <tr><label for="pwd"><b>Password:</b></label>&nbsp;&nbsp;&nbsp;
                <input type="password" placeholder="Enter Password" name="pwd" required/>
                  </tr>
                   <tr><label for="pwd-repeat"><b>Confirm Password:</b></label>&nbsp;&nbsp;&nbsp;
              <input type="password" placeholder="Repeat Password" name="pwd-repeat" required></input>
               </tr></table>
                   <button type="submit" class="signupbtn">Register</button>
             
            </div>
            
            </form>
            
        </div>
    );
}

export default Signup;
